package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Image;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;

public class MainWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 522, 355);
		
		MAINW Prods = new MAINW();
		Compras Comp = new Compras(Prods.getLista());
		Prods.setCompras(Comp);
		Ingresos Ing = new Ingresos();
		Ing.setVentas(Comp.getVentas());
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("Ventanas");
		menuBar.add(mnNewMenu);

		JMenuItem mntmNewMenuItem = new JMenuItem("Productos");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nuevoPanel(Prods);
			}
		});
		mnNewMenu.add(mntmNewMenuItem);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Compra");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nuevoPanel(Comp);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_1);

		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Ganancias");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nuevoPanel(Ing);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Ventana principal");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nuevoPanel(contentPane);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_3);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(224, 255, 255));
		nuevoPanel(contentPane);

		JLabel lblBienvenida = new JLabel("Bienvenido a Admin Products");
		lblBienvenida.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBienvenida.setForeground(new Color(0, 0, 128));
		lblBienvenida.setBounds(134, 11, 281, 14);
		contentPane.add(lblBienvenida);

		JButton btnInventario = new JButton("");
		btnInventario.setBounds(102, 163, 94, 64);
		ImageIcon iconoInventario = new ImageIcon(getClass().getResource("/Imagenes/caja.png"));
		Image imagenEscalada = iconoInventario.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		btnInventario.setIcon(new ImageIcon(imagenEscalada));
		btnInventario.setBorderPainted(false);
		btnInventario.setFocusPainted(false);
		btnInventario.setContentAreaFilled(false);
		btnInventario.setOpaque(false);
		contentPane.add(btnInventario);

		btnInventario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Botón Inventario presionado");
				nuevoPanel(Prods);
			}
		});

		JButton btnCompras = new JButton("");
		btnCompras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Botón Compras presionado");
				nuevoPanel(Comp);
			}
		});
		btnCompras.setBounds(194, 163, 94, 64);
		ImageIcon iconocompras = new ImageIcon(getClass().getResource("/Imagenes/carro.png"));
		Image imagenCompras = iconocompras.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		btnCompras.setIcon(new ImageIcon(imagenCompras));
		btnCompras.setBorderPainted(false);
		btnCompras.setFocusPainted(false);
		btnCompras.setContentAreaFilled(false);
		btnCompras.setOpaque(false);
		contentPane.add(btnCompras);

		JButton btnIngresos = new JButton("");
		btnIngresos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Botón Ingresos presionado");
				nuevoPanel(Ing);
			}
		});
		btnIngresos.setBounds(297, 163, 94, 64);
		ImageIcon iconoingresos = new ImageIcon(getClass().getResource("/Imagenes/ingresos.png"));
		Image imageningresos = iconoingresos.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		btnIngresos.setIcon(new ImageIcon(imageningresos));
		btnIngresos.setBorderPainted(false);
		btnIngresos.setFocusPainted(false);
		btnIngresos.setContentAreaFilled(false);
		btnIngresos.setOpaque(false);
		contentPane.add(btnIngresos);

		JLabel lblNewLabel = new JLabel("INVENTARIO");
		lblNewLabel.setForeground(new Color(0, 0, 128));
		lblNewLabel.setBounds(117, 225, 76, 14);
		contentPane.add(lblNewLabel);

		JLabel lblCompras = new JLabel("COMPRAS");
		lblCompras.setForeground(new Color(0, 0, 128));
		lblCompras.setBounds(215, 225, 76, 14);
		contentPane.add(lblCompras);

		JLabel lblIngresos = new JLabel("INGRESOS");
		lblIngresos.setForeground(new Color(0, 0, 128));
		lblIngresos.setBounds(315, 225, 76, 14);
		contentPane.add(lblIngresos);

		JLabel lblNewLabel_1 = new JLabel("SISTEMA DE GESTION Y VENTAS");
		lblNewLabel_1.setForeground(new Color(0, 0, 128));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(153, 54, 294, 14);
		contentPane.add(lblNewLabel_1);

		

	}

	private void nuevoPanel(JPanel panelAct) {
		   getContentPane().removeAll();
		   getContentPane().add(panelAct, BorderLayout.CENTER);
		   getContentPane().revalidate();
		   getContentPane().repaint();
	}
	
}
